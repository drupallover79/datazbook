Synopsis
---------
This module serve as Payment Gateway porvided by PayUMoney.

Main Module: commerce_payumoney.module
Requried Modules: commerce, pmphone(provided in module itself)

Instructions
------------
1. Install the module.
2. Go to payment setting under store
2.1. enter the required key and salt provided to you by PayUMoney.
2.2. For test purpose
2.2.1 check FAQ by PayUMoney on http://www.payumoney.com or
2.2.2 PHP form provided by PayUMoney on http://www.payumoney.com
3. Select Test or Production based on your use.
4. Under customer profiles in store check PM Phone field.
